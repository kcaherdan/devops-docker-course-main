test('This is a test that always passes', () => {
  expect(true).toBe(true);
});
